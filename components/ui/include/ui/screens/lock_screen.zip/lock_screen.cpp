#include "ui/screens/lock_screen.hpp"

#include "ui/screens/main_menu.hpp"
#include "ui/ui_manager.hpp"
#include "ui/theme.hpp"

#include "security/pin_manager.hpp"
#include "security/lock_manager.hpp"
#include "settings/settings.hpp"

#include "esp_log.h"
#include <cstdio>

#include <memory>

namespace ui::screens {

namespace {

constexpr char TAG[] = "ui.lock_screen";

} // namespace

const char* LockScreen::title() const
{
    return "Unlock";
}

const char* LockScreen::footer_hint() const
{
    return "PIN  Enter    BACK  Return";
}

void LockScreen::initialize(lv_obj_t* content_parent)
{
    root_ = content_parent;

    const theme::Palette& pal = theme::current();

    /*
     * PIN display.
     */
    pin_label_ = lv_label_create(content_parent);

    lv_obj_set_style_text_color(
        pin_label_,
        pal.primary_text,
        0
    );

    lv_label_set_text(
        pin_label_,
        "PIN: "
    );

    lv_obj_align(
        pin_label_,
        LV_ALIGN_TOP_MID,
        0,
        8
    );

    /*
     * Status / error message.
     */
    status_label_ = lv_label_create(content_parent);

    lv_obj_set_style_text_color(
        status_label_,
        pal.secondary_text,
        0
    );

    lv_label_set_text(
        status_label_,
        ""
    );

    lv_obj_align(
        status_label_,
        LV_ALIGN_BOTTOM_MID,
        0,
        -4
    );

    /*
     * Reset PIN input state.
     */
    pin_length_ = 0;
    pin_value_ = 0;

    refresh();
}

void LockScreen::on_show()
{
    /*
     * Every time the lock screen becomes active, start with
     * an empty PIN entry.
     */
    pin_length_ = 0;
    pin_value_ = 0;

    if (status_label_ != nullptr) {
        lv_label_set_text(
            status_label_,
            ""
        );
    }

    refresh();
}

bool LockScreen::on_input(InputAction action)
{
    switch (action) {

        case InputAction::RotateLeft:
            decrement_digit();
            return true;

        case InputAction::RotateRight:
            increment_digit();
            return true;

        case InputAction::OkShort:
            confirm_digit();
            return true;

        case InputAction::BackShort:
            /*
             * Return to the screen below LockScreen.
             *
             * When LockScreen was opened from QuickScreen this
             * returns to QuickScreen.
             */
            return false;

        case InputAction::BackLong:
            /*
             * Long BACK does not unlock anything. Keep the device
             * locked and clear the current PIN entry.
             */
            pin_length_ = 0;
            pin_value_ = 0;

            if (status_label_ != nullptr) {
                lv_label_set_text(
                    status_label_,
                    ""
                );
            }

            refresh();
            return true;

        default:
            return false;
    }
}

void LockScreen::increment_digit()
{
    if (current_digit_ < 9) {
        ++current_digit_;
    } else {
        current_digit_ = 0;
    }

    refresh();
}

void LockScreen::decrement_digit()
{
    if (current_digit_ > 0) {
        --current_digit_;
    } else {
        current_digit_ = 9;
    }

    refresh();
}

void LockScreen::confirm_digit()
{
    /*
     * Add the currently selected digit to the PIN.
     */
    pin_value_ =
        (pin_value_ * 10) +
        current_digit_;

    ++pin_length_;

    current_digit_ = 0;

    /*
     * Current PIN length is four digits.
     */
    if (pin_length_ < PIN_LENGTH) {
        refresh();
        return;
    }

    verify_pin();
}

void LockScreen::verify_pin()
{
    const auto result =
        security::pin::verify(pin_value_);

    switch (result) {

        case security::pin::VerifyResult::Success:

            ESP_LOGI(
                TAG,
                "Unlock successful"
            );

            /*
             * IMPORTANT:
             *
             * Do not use manager().pop() here.
             *
             * pop() would reveal the screen underneath LockScreen
             * and MainMenu would not become the authenticated
             * application screen.
             *
             * replace() removes LockScreen and puts MainMenu in
             * its place. Therefore BACK from MainMenu will return
             * to QuickScreen instead of returning to PIN entry.
             */
            manager().replace(
                std::make_unique<MainMenu>()
            );

            return;

        case security::pin::VerifyResult::Invalid:

            ESP_LOGW(
                TAG,
                "Invalid PIN"
            );

            if (status_label_ != nullptr) {
                lv_label_set_text(
                    status_label_,
                    "Wrong PIN"
                );
            }

            pin_length_ = 0;
            pin_value_ = 0;
            current_digit_ = 0;

            refresh();
            return;

        case security::pin::VerifyResult::Locked:

            ESP_LOGW(
                TAG,
                "PIN verification locked"
            );

            if (status_label_ != nullptr) {
                lv_label_set_text(
                    status_label_,
                    "Locked"
                );
            }

            pin_length_ = 0;
            pin_value_ = 0;
            current_digit_ = 0;

            refresh();
            return;
    }
}

void LockScreen::refresh()
{
    if (pin_label_ == nullptr) {
        return;
    }

    /*
     * Build a masked PIN representation.
     */
    char buffer[32];

    int pos = 0;

    pos += std::snprintf(
        buffer + pos,
        sizeof(buffer) - pos,
        "PIN: "
    );

    for (uint8_t i = 0; i < PIN_LENGTH; ++i) {

        if (i < pin_length_) {
            buffer[pos++] = '*';
        } else {
            buffer[pos++] = '_';
        }

        if (i + 1 < PIN_LENGTH) {
            buffer[pos++] = ' ';
        }
    }

    buffer[pos] = '\0';

    lv_label_set_text(
        pin_label_,
        buffer
    );
}

} // namespace ui::screens